"""
Python translation of main.m: updating the Jarocinski-Karadi (JK) shocks.

Dependencies: numpy, pandas, openpyxl (Excel reader used by pandas).
Local modules: signrestr_median.py, table_d2m2q.py (same directory).
"""

import numpy as np
import pandas as pd

from signrestr_median import signrestr_median
from table_d2m2q import table_d2m2q


def matlab_round(x, n):
    """MATLAB round(x, n): rounds half away from zero (numpy rounds half to even)."""
    x = np.asarray(x, dtype=float)
    f = 10.0 ** n
    return np.sign(x) * np.floor(np.abs(x) * f + 0.5) / f


def normalize_scale_std(X):
    """MATLAB normalize(X, 'scale', 'std'): divide each column by its std
    (N-1 denominator, NaN ignored), without centering."""
    return X / np.nanstd(X, axis=0, ddof=1)


def pca_scores_uncentered(X):
    """MATLAB [~, score] = pca(X, 'Centered', false).

    Rows with any NaN are excluded ('Rows','complete' default) and receive NaN
    scores. Applies MATLAB's sign convention: the largest-magnitude element of
    each coefficient vector is positive.
    """
    complete = ~np.isnan(X).any(axis=1)
    Xc = X[complete]
    _, _, Vt = np.linalg.svd(Xc, full_matrices=False)
    coeff = Vt.T
    maxind = np.argmax(np.abs(coeff), axis=0)
    colsign = np.sign(coeff[maxind, np.arange(coeff.shape[1])])
    coeff = coeff * colsign
    score = np.full((X.shape[0], coeff.shape[1]), np.nan)
    score[complete] = Xc @ coeff
    return score


def main():
    # Interest rate surprises to extract pc from, stock index
    irnames = ["OIS_1M", "OIS_3M", "OIS_6M", "OIS_1Y"]
    stockname = "STOXX50"

    # Load the Altavilla et al. (2019) Monetary Policy Database downloadable from
    # https://www.ecb.europa.eu/pub/pdf/annex/Dataset_EA-MPD.xlsx
    # use the Monetary Event Window
    fname = "../source_data/Dataset_EA-MPD.xlsx"
    tab = pd.read_excel(fname, sheet_name="Monetary Event Window")
    tab["date"] = pd.to_datetime(tab["date"])
    # equivalent of setvartype(..., 'double') for columns 2:end
    for c in tab.columns[1:]:
        tab[c] = pd.to_numeric(tab[c], errors="coerce")

    # Select the sample: drop joint Fed and ECB announcements
    drop_dates = pd.to_datetime([
        "2001-09-13",  # joint announcement of USD swap
        "2001-09-17",  # joint cut at 17:30
        "2008-10-08",  # joint cut
    ])
    tab = tab.loc[~tab["date"].isin(drop_dates)].reset_index(drop=True)
    print("Data from %s to %s, T=%d" % (tab["date"].iloc[0].strftime("%Y-%m-%d"),
                                         tab["date"].iloc[-1].strftime("%Y-%m-%d"),
                                         len(tab)))

    # Compute the 1st principal component
    X = tab[irnames].to_numpy(dtype=float)
    score = pca_scores_uncentered(normalize_scale_std(X))
    # rescale the 1st principal component
    pc1 = (score[:, 0] / np.nanstd(score[:, 0], ddof=1)
           * np.nanstd(tab["OIS_1Y"].to_numpy(dtype=float), ddof=1) / 100)

    # add pc1 to the table
    tab["pc1"] = matlab_round(pc1, 8)

    # keep only the variables we need
    tab = tab[["date", "pc1", stockname]].copy()

    # Compute the poor man and median rotation shocks
    M = tab[["pc1", stockname]].to_numpy(dtype=float)
    prodM = np.prod(M, axis=1)
    # poor man's shocks
    U_pm = np.column_stack([M[:, 0] * (prodM < 0), M[:, 0] * (prodM >= 0)])
    # median rotation shocks
    U_median, _, _ = signrestr_median(M)

    # Save daily shocks
    shocks_names = ["MP_pm", "CBI_pm", "MP_median", "CBI_median"]
    shocks_table = pd.DataFrame(matlab_round(np.hstack([U_pm, U_median]), 8),
                                columns=shocks_names)
    tab = pd.concat([tab, shocks_table], axis=1)
    filename_d = "../shocks/shocks_ecb_mpd_me_d.csv"
    tab.to_csv(filename_d, index=False, date_format="%Y-%m-%d", na_rep="NaN")

    # Aggregate to monthly
    mtab, _ = table_d2m2q(tab)
    # add a suffix to pc1 and stock (MATLAB columns 3:4)
    cols = list(mtab.columns)
    cols[2] = cols[2] + "_hf"
    cols[3] = cols[3] + "_hf"
    mtab.columns = cols
    mtab.to_csv(filename_d.replace("_d", "_m"), index=False, na_rep="NaN")


if __name__ == "__main__":
    main()
