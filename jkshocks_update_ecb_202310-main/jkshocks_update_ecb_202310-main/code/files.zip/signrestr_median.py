"""
Python translation of signrestr_median.m (Marek Jarocinski).

PURPOSE: Decompose M (= [M1 M2]) into two orthogonal shocks U (= [U1 U2])
such that U1 + U2 = M1, the effect of U1 is positive on M1 and negative on M2,
while the effect of U2 is positive on both M1 and M2.
The decomposition satisfies M = U @ C, where
    C = [[effect of U1 on M1 = 1, effect of U1 on M2 < 0],
         [effect of U2 on M1 = 1, effect of U2 on M2 > 0]].
Finds the median shocks that satisfy the sign restrictions.

SEE:
Motivation: Jarocinski, M. and Karadi, P. (2020) Deconstructing Monetary
Policy Surprises: The Role of Information Shocks, AEJ: Macro.
This implementation: Appendix B of Jarocinski, M. (2020) Central Bank
Information Effects and Transatlantic Spillovers, ECB Working Paper 2482.
"""

import numpy as np


def signrestr_median(M, w=0.5):
    """
    Parameters
    ----------
    M : array_like, shape (T, 2)
    w : float, optional
        Quantile of the rotation angle, between 0 and 1.
        The default w = 0.5 gives the median rotation angle.

    Returns
    -------
    U : ndarray, shape (T, 2)   orthogonal shocks (NaN rows where M has NaN)
    C : ndarray, shape (2, 2)   their effects on M
    a : float                   rotation angle
    """
    M = np.asarray(M, dtype=float)

    # handle missing data (if any)
    inotnan = ~np.isnan(M.sum(axis=1))
    MM = M[inotnan, :]

    # economy-size QR, as in MATLAB qr(MM, 0)
    Q, R = np.linalg.qr(MM, mode="reduced")
    # normalize so that diag(R) > 0; this makes the factorization unique,
    # so the result does not depend on the LAPACK sign convention
    S = np.diag(np.sign(np.diag(R)))
    Q = Q @ S
    R = S @ R

    with np.errstate(divide="ignore"):  # MATLAB: atan(+-Inf) = +-pi/2
        if R[0, 1] > 0:
            a = (1 - w) * np.arctan(R[0, 1] / R[1, 1]) + w * np.pi / 2
        else:
            a = (1 - w) * 0 + w * np.arctan(-R[1, 1] / R[0, 1])

    P = np.array([[np.cos(a), np.sin(a)],
                  [-np.sin(a), np.cos(a)]])
    D = np.diag([R[0, 0] * np.cos(a), R[0, 0] * np.sin(a)])

    UU = Q @ P @ D
    C = np.linalg.solve(D, P.T) @ R  # MATLAB: D\P'*R
    U = np.full(M.shape, np.nan)
    U[inotnan, :] = UU
    return U, C, a
