"""
Python translation of table_d2m2q.m.

PURPOSE: Aggregate data at (intra-)daily frequency to monthly and quarterly
frequency by adding up.
"""

import numpy as np
import pandas as pd


def table_d2m2q(table_d):
    """
    Parameters
    ----------
    table_d : pandas.DataFrame
        (Intra-)daily data; the first column holds dates, the remaining
        columns are numeric.

    Returns
    -------
    table_m : pandas.DataFrame
        Monthly data. The first two columns are year and month; the remaining
        columns contain the variables of table_d summed over the month, or 0
        if no day of that month is present in table_d.
    table_q : pandas.DataFrame
        Quarterly data. The first two columns are year and quarter.
    """
    datecol = pd.to_datetime(table_d.iloc[:, 0])
    data_d = table_d.iloc[:, 1:].to_numpy(dtype=float)
    varnames = [str(v) for v in table_d.columns[1:]]
    nvar = data_d.shape[1]

    y_d = datecol.dt.year.to_numpy()
    m_d = datecol.dt.month.to_numpy()
    years = np.arange(y_d[0], y_d[-1] + 1)

    # Aggregate to monthly
    # List of all years and months without holes
    ym = np.column_stack([np.repeat(years, 12),
                          np.tile(np.arange(1, 13), len(years))])
    ym = ym[~((ym[:, 0] == years[0]) & (ym[:, 1] < m_d[0]))]
    ym = ym[~((ym[:, 0] == years[-1]) & (ym[:, 1] > m_d[-1]))]
    Tm = ym.shape[0]

    # Aggregate daily to monthly (NaN propagates, as MATLAB sum does;
    # months with no observations get 0)
    data_m = np.zeros((Tm, nvar))
    for m in range(Tm):
        tsel = (y_d == ym[m, 0]) & (m_d == ym[m, 1])
        data_m[m, :] = np.sum(data_d[tsel, :], axis=0)

    # rename year, month if they exist, to avoid conflict
    varnames = [v.replace("year", "year2") for v in varnames]
    varnames = [v.replace("month", "month2") for v in varnames]

    table_m = pd.DataFrame({"year": ym[:, 0], "month": ym[:, 1]})
    table_m = pd.concat(
        [table_m, pd.DataFrame(data_m, columns=varnames)], axis=1)

    # Aggregate to quarterly
    def m2q(mo):
        return np.ceil(np.asarray(mo) / 3).astype(int)

    # List of all years and quarters
    yq = np.column_stack([np.repeat(years, 4),
                          np.tile(np.arange(1, 5), len(years))])
    yq = yq[~((yq[:, 0] == years[0]) & (yq[:, 1] < m2q(ym[0, 1])))]
    yq = yq[~((yq[:, 0] == years[-1]) & (yq[:, 1] > m2q(ym[-1, 1])))]
    Tq = yq.shape[0]

    # Aggregate monthly to quarterly
    data_q = np.zeros((Tq, nvar))
    q_of_ym = m2q(ym[:, 1])
    for q in range(Tq):
        tsel = (ym[:, 0] == yq[q, 0]) & (q_of_ym == yq[q, 1])
        data_q[q, :] = np.sum(data_m[tsel, :], axis=0)

    table_q = pd.DataFrame({"year": yq[:, 0], "quarter": yq[:, 1]})
    table_q = pd.concat(
        [table_q, pd.DataFrame(data_q, columns=varnames)], axis=1)

    return table_m, table_q
